package src.datastructure.unionfind;

/**
 * Pleceholder class for a generic union find node.
 */
public interface UFnode {
		
}
